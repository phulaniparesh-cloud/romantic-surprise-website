# Romantic Surprise Website

A beginner-friendly, mobile-friendly romantic surprise website built with plain HTML, CSS, and JavaScript.

## 1. Personalize it
Open `script.js` and edit:
- `recipientName`
- `senderName`
- `passcode` (must be four digits)

The passcode is only a playful lock screen. Anyone who can inspect the code can discover it, so do not use a real password.

## 2. Add photos
Put three image files in `assets/` and name them exactly:
- `photo1.jpg`
- `photo2.jpg`
- `photo3.jpg`

Use JPG files for the easiest setup. If your pictures are PNG, either convert them to JPG or change the filenames in `index.html`.

## 3. Add music
Put an MP3 you have permission to use in `assets/` and name it `music.mp3`.
Browsers generally require a person to tap a button before music can start. The page has a music button for that reason.

## 4. Run in VS Code
1. Extract this ZIP.
2. Open VS Code.
3. Choose **File → Open Folder** and select `romantic_surprise_website`.
4. Install the **Live Server** extension if needed.
5. Right-click `index.html` → **Open with Live Server**.
6. Try code `1430` (unless you changed it).

You can also open `index.html` directly in a browser, but Live Server is recommended while editing.

## 5. Publish free with GitHub Pages
1. Sign in or create an account at https://github.com/
2. Create a new public repository, for example `romantic-surprise`.
3. Upload `index.html`, `style.css`, `script.js`, and the entire `assets` folder. Do not upload only the HTML file.
4. In the repository, open **Settings → Pages**.
5. Under Build and deployment, select **Deploy from a branch**, choose `main` and `/ (root)`, then save.
6. Wait a few minutes. GitHub Pages will show the published website URL in Settings → Pages.
7. Open that URL on your phone and test all buttons, photos, passcode and music.

## 6. Make a QR code
After the public website link works, use a reputable QR-code generator, paste the link, create the code, and scan-test it with your phone before sharing.

## Important privacy note
A public GitHub Pages site can be visited by anyone with the link. Only use photos and music you have permission to share. Do not upload private or sensitive images. The passcode is not real security because it is stored in browser JavaScript.
