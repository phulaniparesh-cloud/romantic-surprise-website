/*
  PERSONALIZE THIS SECTION:
  - Change the names and passcode below.
  - Passcode is a simple surprise gate, not secure authentication.
*/
const SETTINGS = {
  recipientName: "Riya",
  senderName: "Sahil",
  passcode: "2006", // Change to any 4-digit code.
};

const screens = [...document.querySelectorAll(".screen")];
const pinDots = [...document.querySelectorAll("#pinDots span")];
const lockMessage = document.getElementById("lockMessage");
const toast = document.getElementById("toast");
const music = document.getElementById("backgroundMusic");
let enteredCode = "";
let musicOn = false;

document.getElementById("personName").textContent = SETTINGS.recipientName;
document.getElementById("letterName").textContent = SETTINGS.recipientName;
document.getElementById("senderName").textContent = SETTINGS.senderName;

function showScreen(id) {
  screens.forEach(screen => screen.classList.toggle("active", screen.id === id));
  window.scrollTo({ top: 0, behavior: "smooth" });
}
document.querySelectorAll("[data-go]").forEach(button => {
  button.addEventListener("click", () => showScreen(button.dataset.go));
});

function updateDots() {
  pinDots.forEach((dot, index) => dot.classList.toggle("filled", index < enteredCode.length));
}
function toastMessage(message) {
  toast.textContent = message;
  toast.classList.add("show");
  window.setTimeout(() => toast.classList.remove("show"), 2300);
}
function pressKey(key) {
  if (key === "clear") enteredCode = "";
  else if (key === "back") enteredCode = enteredCode.slice(0, -1);
  else if (enteredCode.length < 4) enteredCode += key;
  updateDots();

  if (enteredCode.length === 4) {
    if (enteredCode === SETTINGS.passcode) {
      lockMessage.textContent = "Opening your surprise… 💗";
      window.setTimeout(() => showScreen("welcomeScreen"), 450);
    } else {
      lockMessage.textContent = "Not quite! Try again, lovely 💌";
      enteredCode = "";
      window.setTimeout(updateDots, 300);
    }
  } else {
    lockMessage.textContent = "Hint: a special date 💌";
  }
}
document.getElementById("keypad").addEventListener("click", event => {
  const button = event.target.closest("button[data-key]");
  if (button) pressKey(button.dataset.key);
});
document.addEventListener("keydown", event => {
  if (!document.getElementById("lockScreen").classList.contains("active")) return;
  if (/^\d$/.test(event.key)) pressKey(event.key);
  if (event.key === "Backspace") pressKey("back");
  if (event.key === "Escape") pressKey("clear");
});

const giftMessages = [
  "Gift one: A reminder that your smile can make an ordinary day better. 💗",
  "Gift two: A tiny bunch of tulips, just for you. 🌷",
  "Gift three: Your letter is waiting on the next page. 💌"
];
document.querySelectorAll("[data-gift]").forEach(button => {
  button.addEventListener("click", () => {
    button.classList.add("opened");
    button.querySelector(".gift-emoji").textContent = ["💖", "🌷", "💌"][Number(button.dataset.gift)];
    document.getElementById("giftMessage").textContent = giftMessages[Number(button.dataset.gift)];
  });
});

async function toggleMusic() {
  if (!musicOn) {
    try {
      await music.play();
      musicOn = true;
      toastMessage("Music is playing ♫");
    } catch {
      toastMessage("Add assets/music.mp3, then tap again.");
      return;
    }
  } else {
    music.pause();
    musicOn = false;
    toastMessage("Music paused");
  }
  document.getElementById("musicToggle").textContent = musicOn ? "♫ Pause music" : "♫ Turn music on";
}
document.getElementById("musicToggle").addEventListener("click", toggleMusic);
document.getElementById("musicToggleEnd").addEventListener("click", toggleMusic);
document.getElementById("finalButton").addEventListener("click", () => {
  enteredCode = "";
  updateDots();
  lockMessage.textContent = "Hint: a special date 💌";
  document.querySelectorAll(".gift").forEach((gift, index) => {
    gift.classList.remove("opened");
    gift.querySelector(".gift-emoji").textContent = ["🎁", "🎀", "💌"][index];
  });
  document.getElementById("giftMessage").textContent = "Your gifts are waiting ✨";
  showScreen("lockScreen");
});

// Gentle floating hearts; no external libraries needed.
const heartLayer = document.querySelector(".floating-hearts");
const heartSymbols = ["♡", "♥", "✧", "♥"];
function addHeart() {
  const heart = document.createElement("span");
  heart.className = "float-heart";
  heart.textContent = heartSymbols[Math.floor(Math.random() * heartSymbols.length)];
  heart.style.left = `${Math.random() * 100}%`;
  heart.style.fontSize = `${12 + Math.random() * 18}px`;
  heart.style.animationDuration = `${8 + Math.random() * 8}s`;
  heart.style.color = Math.random() > .5 ? "#e8759b" : "#d6a0b5";
  heartLayer.appendChild(heart);
  window.setTimeout(() => heart.remove(), 17000);
}
for (let i = 0; i < 12; i++) window.setTimeout(addHeart, i * 500);
window.setInterval(addHeart, 1200);
